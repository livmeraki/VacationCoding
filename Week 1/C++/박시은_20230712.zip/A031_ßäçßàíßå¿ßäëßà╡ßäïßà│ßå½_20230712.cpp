#include <iostream>
using namespace std;

int main(){
    int N, M;
    cin >> N >> M;
    cout << N*M-1;
    return 0;
}